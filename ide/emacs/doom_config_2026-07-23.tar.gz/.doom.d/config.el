;;; $DOOMDIR_config.el -*- lexical-binding: t; -*-

;; --- 1. IDENTITÉ & PROXY EDF ---
(setq user-full-name "Xavier LEJUS"
      user-mail-address "xavier-externe.lejus@edf.fr")

(setq url-proxy-services
      `(("http" . "vip-users.proxy.edf.fr:3131")
        ("https" . "vip-users.proxy.edf.fr:3131")
        ("no_proxy" . ,(regexp-opt
                         '("localhost"
                           "127.0.0.1"
                           "git-s2i.dpih.edf.fr"
                           "nexus-s2i.cih.dpih.edf.fr"
                           "si-devops-mirror.edf.fr")))))

;; On ignore le proxy pour les services locaux (Ollama)
(setq url-gateway-local-host-regexp
      (concat "\\(" "localhost" "\\|" "127.0.0.1" "\\|10\\..*" "\\)"))

;; ------------------------------------------------------------------
;; Environnement EDF / Gemini
;; ------------------------------------------------------------------
(setenv "HTTP_PROXY"  "http://vip-users.proxy.edf.fr:3131")
(setenv "HTTPS_PROXY" "http://vip-users.proxy.edf.fr:3131")

(setenv "http_proxy" (getenv "HTTP_PROXY"))
(setenv "https_proxy" (getenv "HTTPS_PROXY"))

;; EDF Gemini : si-devops-mirror.edf.fr")
(setenv "NO_PROXY"
        "localhost,127.0.0.0/8,::1,git-s2i.dpih.edf.fr,nexus-s2i.cih.dpih.edf.fr,si-devops-mirror.edf.fr")

(setenv "no_proxy" (getenv "NO_PROXY"))

(setenv "NODE_USE_ENV_PROXY" "1")
(setenv "NODE_NO_WARNINGS" "1") ;; Pour ne pas afficher les warnings lors de npx @google/gemini-cli

(setenv "NODE_EXTRA_CA_CERTS"
        "/etc/pki/ca-trust/source/anchors/certificats_edf.pem")

(setenv "GOOGLE_CLOUD_PROJECT"
        "prj-cedid-clf-prd-iad-64512")
;; ------------------------------------------------------------------

;; Désactiver la vérification SSL (souvent nécessaire avec les proxys d'entreprise)
;; (setq gnutls-verify-error nil)
;; (setq tls-checktrust nil)

;; 2. RECHERCHE (SPC s p) AVEC TUNNEL FLATPAK ---
(after! consult
  ;; Activation de l'aperçu automatique (preview) lors de la navigation dans les résultats
  (consult-customize consult-ripgrep :preview-key 'any))

;; Force SPC s p à utiliser consult-ripgrep (qui gère le tunnel)
(map! :leader :desc "Search project" "s p" #'consult-ripgrep)

;; Force SPC s d à utiliser consult-fd (qui gère le tunnel)
;; (map! :leader :desc "Search project with fd" "s d" #'consult-fd)

;; --- 3. CONFIGURATION LSP (C++ _ CLANGD) VIA TUNNEL --- SANS HINTS
(after! lsp-mode
  (lsp-register-client
   (make-lsp-client
    :new-connection (lsp-tramp-connection
                     '("clangd"
                       "--header-insertion=never"
                       "--all-scopes-completion"
                       "--background-index"
                       "--pch-storage=memory"
                       "--completion-style=detailed"
                       "--header-insertion=never"
                       ;; L'argument unique suggéré par ton clangd
                       "--clang-tidy"
                       "--inlay-hints"))
    :major-modes '(c-mode c++-mode)
    :server-id 'clangd-flatpak))

  ;; Force l'usage de notre client personnalisé
  (setq lsp-clients-clangd-executable nil)

  ;; Configuration de l'affichage dans Emacs
  (setq lsp-inlay-hint-enable t)

  ;; Réglages d'automatisation
  (setq lsp-auto-guess-root t
        lsp-enable-symbol-highlighting t
        lsp-lens-enable t)

  ;; Optionnel : Personnalisation esthétique
  (custom-set-faces!
    '(lsp-inlay-hint-face :italic t :foreground "#5B6268" :height 0.85)))

;; --- 4. ACTIVATION AUTOMATIQUE (HOOKS) ---
;; Ne pas activer les inlay hints partout
(remove-hook 'lsp-mode-hook #'lsp-inlay-hints-mode)

;; Activer les inlay hints seulement pour C/C++
(add-hook 'c-mode-hook   #'lsp-inlay-hints-mode)
(add-hook 'c++-mode-hook #'lsp-inlay-hints-mode)

;; --- PYTHON ---
(after! lsp-pyright
  (setq lsp-pyright-typechecking-mode "strict"
        lsp-pyright-auto-import-completions t
        lsp-pyright-use-library-code-for-types t))

;; On utilise lsp-deferred pour garantir que LSP se lance seul à l'ouverture du fichier
(add-hook! '(c-mode-hook c++-mode-hook python-mode-hook) #'lsp-deferred)

;; --- 5. TREEMACS (COMPACT & REDIMENSIONNABLE) ---
(after! treemacs
  (setq treemacs-width 32)
  (setq treemacs-lock-width nil)      ; Autorise le redimensionnement manuel
  (setq treemacs-width-is-fixed nil) ; Empêche le verrouillage automatique de Doom
  (setq treemacs-icon-size 13)
  (setq treemacs-text-scale 0)
  (setq treemacs-header-line-format nil))

;; Réduction visuelle de la police pour gagner de la place
;; (custom-set-faces!
;;   '(treemacs-file-face :height 0.8)
;;   '(treemacs-directory-face :height 0.8 :weight semi-bold))

;; --- 6. TERMINAL (VTERM) & PRESSE-PAPIER ---
(setenv "TERM" "xterm-256color")

;; (after! vterm
;;   ;; Le terminal sort du conteneur pour accéder à l'hôte AlmaLinux
;;   (setq vterm-shell "flatpak-spawn --host /bin/bash")
;;   (setenv "TERM" "xterm-256color"))

;; Synchronisation avec le presse-papier système (AlmaLinux)
(setq select-enable-clipboard t
      select-enable-primary t)

;; --- 7. APPARENCE & ORG ---
(setq doom-theme 'doom-one)
(setq display-line-numbers-type t)
(setq org-directory "~/org/")

;; --- 7. DOCKER ---
(setenv "DOCKER_HOST" "unix:///var/run/docker.sock")

;; 8. PLANTUML (LOCAL) ---
;; Objectif : preview locale (pas de serveur), génération PNG/SVG depuis Emacs/Org.

(use-package! plantuml-mode
  :mode (("\\.puml\\'" . plantuml-mode)
         ("\\.plantuml\\'" . plantuml-mode)
         ("\\.pu\\'" . plantuml-mode))
  :config
  ;; IMPORTANT : forcer l'exécution locale pour éviter tout rendu via serveur
  ;; plantuml-mode supporte 'jar ou 'executable en local. [2](https://github.com/skuro/plantuml-mode)

  ;; Option A (recommandée si 'plantuml' est installé sur AlmaLinux) :
  (setq plantuml-default-exec-mode 'executable)
  (setq plantuml-executable-path "plantuml")

  ;; Option B (si tu utilises un jar local) : décommente et ajuste le chemin
  ;; (setq plantuml-default-exec-mode 'jar)
  ;; (setq plantuml-jar-path (expand-file-name "~/tools/plantuml/plantuml.jar"))

  ;; Format de sortie pour la preview
  (setq plantuml-output-type "png"))

;; 8bis. ORG BABEL : activer PlantUML ---
(after! org
  ;; Activer l'exécution des blocs PlantUML dans Org Babel [3](https://orgmode.org/worg/org-contrib/babel/languages/ob-doc-plantuml.html)
  (org-babel-do-load-languages
   'org-babel-load-languages
   (append org-babel-load-languages '((plantuml . t))))

  ;; Dire à Org Babel comment exécuter PlantUML :
  ;; - soit via exécutable local, soit via jar local. [3](https://orgmode.org/worg/org-contrib/babel/languages/ob-doc-plantuml.html)
  (setq org-plantuml-exec-mode 'plantuml)
  ;; Si jar local :
  ;; (setq org-plantuml-jar-path (expand-file-name "~/tools/plantuml/plantuml.jar"))
  )

;; 9. IA : ELLAMA & GPTEL ---

;; Ollama + Modèle local
(use-package! ellama
  :init
  ;; Configurer la langue par défaut
  (setq ellama-language "French")
  :config
  ;; Définir Mistral comme fournisseur par défaut
  (require 'llm-ollama)
  (setq ellama-provider
        (make-llm-ollama
         ;; tinyllama est rapide, mais pour du C++ envisagez des modèles plus puissants
         ;; comme "codellama", "mistral" ou "llama3" via Ollama.
         :chat-model "tinyllama"
         :embedding-model "tinyllama")))

;; gptel pour les services externes (Ollama, Gemini, Mistral)
(use-package! gptel
  :config
  ;; 1. Configurer Ollama pour gptel (utilise votre instance locale)
  (setq-default gptel-backend
                (gptel-make-ollama "Ollama"
                  :host "localhost:11434"
                  :stream t
                  :models '("tinyllama")))

  ;; 2. Ajouter Google Gemini (Utilise votre clé fournie)
  (gptel-make-gemini "Gemini"
    :key (getenv "GEMINI_API_KEY")
    :stream t
    :models '("gemini-2.5-flash-lite" "gemini-2.5-flash" "gemini-2.5-pro"))

  ;; Backend Mistral AI (Version compatible avec ton environnement EDF)
  (gptel-make-openai "Mistral"
    :host "api.mistral.ai"
    :endpoint "/v1/chat/completions"
    :protocol "https"                    ; Force le HTTPS
    :key "s26lfJuKdglfKcVBfV2Ivo0M7I9HTK7J"
    :stream t
    :models '("mistral-small-latest" "pixtral-12b-latest" "mistral-large-latest"))
)

;; --- Specification du prompt ---
(setq gptel-directives
      '((default . "Tu es un assistant IA utile. Réponds de manière concise et en français.")
        (cpp-senior . "Tu es un développeur C++ Senior expert.
Ton objectif est de produire du code C++ moderne (C++17/20/23) de haute qualité.
- Réponds exclusivement en français.
- Priorise le RAII, les smart pointers (unique_ptr, shared_ptr) et la sécurité mémoire.
- Utilise les fonctionnalités modernes : auto, concepts, ranges, constexpr, moves semantics.
- Analyse la complexité algorithmique si pertinent.
- Ne te contente pas de donner le code : explique *pourquoi* cette approche est la meilleure selon les standards de l'industrie.
- Si une solution plus simple ou plus performante existe, propose-la.")
        (python-senior . "Tu es un développeur Python senior.
- Réponds exclusivement en français.
- Utilise Python 3.12+.
- Utilise typing lorsque pertinent.
- Préfère pathlib à os.path.
- Préfère dataclass aux classes simples.
- Respecte PEP8.
- Respecte Ruff.
- Évite le code inutilement complexe.
- Documente brièvement les choix techniques.")
        (linux-expert . "Tu es un expert en administration système Linux et scripting Bash.
- Réponds exclusivement en français.
- Propose des solutions robustes, sécurisées et conformes aux bonnes pratiques (POSIX, sécurité).
- Explique les flags des commandes utilisées.")))

;; --- Raccourcis clavier spécifiques à Doom Emacs ---
(map! :leader
      (:prefix ("i" . "IA")
       :desc "Menu gptel (Changer de modèle)" "g" #'gptel-menu
       :desc "Envoyer à l'IA"                "s" #'gptel-send
       :desc "Ouvrir un buffer de chat"      "c" #'gptel))

(defun my/refresh-headerline-after-consult (&rest _)
  "Force LSP à recalculer le breadcrumb et rafraîchir la header-line."
  (interactive)
  ;; On vérifie que le mode breadcrumb est actif
  (when (and (bound-and-true-p lsp-headerline-breadcrumb-mode)
             (fboundp 'lsp-headerline-breadcrumb--set-display-string))
    ;; 1. On force LSP à mettre à jour la variable contenant les symboles
    (ignore-errors (lsp-headerline-breadcrumb--set-display-string))
    ;; 2. On demande à Emacs de redessiner la header-line
    (force-mode-line-update t)))

(after! consult
  ;; Hook pour le saut final (Entrée)
  (add-hook 'consult-after-jump-hook #'my/refresh-headerline-after-consult)

  ;; Hook pour la prévisualisation (Navigation dans la liste)
  ;; On utilise add-to-list pour s'assurer qu'il est dans la "liste blanche" de Consult
  (add-to-list 'consult-preview-allowed-hooks #'my/refresh-headerline-after-consult))

;; Configurer eww
(use-package! eww
  :config
  (setq eww-browse-url-browser-function 'eww-browse-with-external-browser)
  (setq eww-browse-url-new-session-function 'eww-browse-with-external-browser))

;; --- chrome avec EDF IA ---
;; Définition d'une fonction pour ouvrir le portail AI d'EDF
(defun my/open-edf-ai-portal ()
  "Ouvre le portail AI Knowledge Chat d'EDF dans le navigateur par défaut."
  (interactive)
  (browse-url "https://iag.edf.fr/fr/product/ai-knowledge-chat/agent?id=group%3Aportail"))

;; --- chrome avec EDF Outlook IA ---
;; Définition d'une fonction pour ouvrir le portail outlook IA
(defun my/open-edf-ai-outlook ()
  "Ouvre outlook AI EDF."
  (interactive)
  (browse-url "https://outlook.cloud.microsoft/mail"))

;; --- chrome avec EDF Copilot ---
;; Définition d'une fonction pour ouvrir le portail copilot
(defun my/open-edf-ai-copilot ()
  "Ouvre Copilot AI EDF."
  (interactive)
  (browse-url "https://m365.cloud.microsoft/chat/conversation"))

;; --- chrome avec EDF Gitlab ---
;; Définition d'une fonction pour ouvrir le portail AI d'EDF
(defun my/open-edf-gitlab-portal ()
  "Ouvre le portail gitlab d'EDF dans le navigateur par défaut."
  (interactive)
  (browse-url "https://git-s2i.dpih.edf.fr"))

;; --- chrome avec EDF Developpeur augmente ---
;; Définition d'une fonction pour ouvrir le portail Developpeur augmente d'EDF
(defun my/open-edf-ai-portal-dev ()
  "Ouvre le portail développeur augmenté d'EDF dans le navigateur par défaut."
  (interactive)
  (browse-url "https://www.myelectricnetwork.fr/web/edf-developpeur-augmente"))

;; --- chrome avec EDF IGC Wiki ---
;; Définition d'une fonction pour ouvrir le wiki d'IGC
(defun my/open-edf-igc-wiki ()
  "Ouvre le wiki d'IGC dans le navigateur par défaut."
  (interactive)
  (browse-url "https://wiki-igc.dpih.edf.fr/index.php/Accueil"))

;; --- chrome avec EDF Nexus ---
;; Définition d'une fonction pour ouvrir le portail Nexus d'EDF
(defun my/open-edf-nexus ()
  "Ouvre le portail Nexus d'EDF dans le navigateur par défaut."
  (interactive)
  (browse-url "https://nexus-s2i.cih.dpih.edf.fr/#browse/welcome"))

;; chrome avec EDF Master ---
;; Définition d'une fonction pour ouvrir le wiki MASTER
(defun my/open-edf-master-wiki ()
  "Ouvre le wiki de MASTER dans le navigateur par défaut."
  (interactive)
  (browse-url "https://wiki-master.cih.dpih.edf.fr/pocs/proxmox-8/proxmox-8-installation"))

;; chrome avec EDF ---
;; Définition d'une fonction pour ouvrir hopp
(defun my/open-edf-hopp ()
  "Ouvre hopp dans le navigateur par défaut."
  (interactive)
  (browse-url "https://hydro-hopp.edf.fr"))

;; Gemini avec EDF ---
;; Ouvre un vterm lançant @google/gemini-cli
(after! vterm

  ;; Réutilise toujours le buffer principal Gemini
  (defun my/open-gemini-cli ()
    "Ouvre ou réutilise le buffer Gemini principal."
    (interactive)

    (if-let ((buf (get-buffer "*Gemini CLI*")))
        (switch-to-buffer buf)
      (progn
        (vterm "*Gemini CLI*")
        (vterm-send-string "npx @google/gemini-cli")
        (vterm-send-return))))

  ;; Crée un nouveau buffer Gemini
  (defun my/open-gemini-cli-new ()
    "Ouvre Gemini CLI dans un nouveau buffer VTerm."
    (interactive)

    (let ((buffer (generate-new-buffer-name "*Gemini CLI*")))
      (vterm buffer)
      (vterm-send-string "npx @google/gemini-cli")
      (vterm-send-return))))

;; Mapping EDF ---
(map! :leader
      (:prefix ("e" . "open")
       :desc "Gemini CLI"               "e" #'my/open-gemini-cli
       :desc "Gemini CLI [NEW BUFFER]" "E" #'my/open-gemini-cli-new
       :desc "EDF portail IA"           "a" #'my/open-edf-ai-portal
       :desc "EDF outlook"              "o" #'my/open-edf-ai-outlook
       :desc "EDF copilot"              "c" #'my/open-edf-ai-copilot
       :desc "EDF gitlab"               "g" #'my/open-edf-gitlab-portal
       :desc "EDF développeur IA"       "d" #'my/open-edf-ai-portal-dev
       :desc "EDF MASTER wiki"          "m" #'my/open-edf-master-wiki
       :desc "EDF Nexus"                "n" #'my/open-edf-nexus
       :desc "EDF Hopp"                 "h" #'my/open-edf-hopp
       :desc "EDF IGC wiki"             "i" #'my/open-edf-igc-wiki))

;; Corfu
(after! corfu
  (setq corfu-auto t
        corfu-auto-delay 0.0          ; Instantané !
        corfu-auto-prefix 1)

  ;; Permet d'utiliser TAB pour naviguer dans les suggestions
  (map! :map corfu-map
        "TAB"        #'corfu-next
        [tab]        #'corfu-next
        "S-TAB"      #'corfu-previous
        [backtab]    #'corfu-previous))

;; Mapping workspaces
(map! :leader
      (:prefix ("l" . "workspaces")
       :desc "Switch to workspace" "l" #'+workspace/switch-to
       :desc "Switch to other workspace" "o" #'+workspace/other))
